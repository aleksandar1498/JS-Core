/**
 * 
 */
package com.dxc.medxc.init;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.dxc.medxc.implementation.DoctorServiceImpl;
import com.dxc.medxc.services.DoctorService;

/**
 * Application initialization and destruction on start/shutdown.
 * @author amirchev
 *
 */
public final class AppContextListener implements ServletContextListener {
    
    /**
     * Context initializing and configuring on application start.
     * Override from {@link javax.servlet.ServletContextListener#contextInitialized(ServletContextEvent)}
     * @param sce Servlet Context Event we get from server.
     */
    @SuppressWarnings("nls")
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        
        final ServletContext context = sce.getServletContext();
        final DoctorService service = new DoctorServiceImpl();
        context.setAttribute("Service", service);
        System.out.println("Starting up!");
        
    }
    
    /**
     * Destroying context on application shutdown.
     * Override from {@link javax.servlet.ServletContextListener#contextDestroyed(ServletContextEvent) contextDestroyed}
     * @param sce Servlet Context Event we get from server.
     */
    @SuppressWarnings("nls")
    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Shutting down!");        
    }

}
