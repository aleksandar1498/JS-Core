/**
 * Package contains AppContextListener which includes methods that are run on start up and shut down of application.
 * @author amirchev
 *
 */
package com.dxc.medxc.init;
