package com.dxc.medxc.rest;

import java.util.List;

import javax.servlet.ServletContext;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.dxc.medxc.dto.DoctorDTO;
import com.dxc.medxc.services.DoctorService;

/**
 * @author astefanov2
 */
@Path("doctors")
public class RestMedic {
    @Context
    private ServletContext context;

    /**
     * @return a JSON representation of the Doctors retrieved from the service
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<DoctorDTO> getAllDoctors() {
        return getService().getAllDoctors();
    }

    /**
     * @param id is the criteria by which a Doctor/Doctors are removed
     * @return
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<DoctorDTO> removeDoctor(@PathParam("id") final int id) {
        return getService().deleteDoctor(id);
    }

    /**
     *
     * @return the DoctorService from the ServletContext
     */
    @SuppressWarnings("nls")
    private DoctorService getService() {
        return (DoctorService) context.getAttribute("Service");
    }
}
