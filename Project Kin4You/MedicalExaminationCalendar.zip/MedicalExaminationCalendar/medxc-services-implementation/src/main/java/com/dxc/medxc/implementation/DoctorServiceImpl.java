package com.dxc.medxc.implementation;

import java.util.ArrayList;
import java.util.List;

import com.dxc.medxc.dto.DoctorDTO;
import com.dxc.medxc.services.DoctorService;

/**
 * Implementation of the dorctor services
 * 
 * @author atsekov
 */
public final class DoctorServiceImpl implements DoctorService {

    static {
        arr = new ArrayList<>();
        final DoctorDTO a = new DoctorDTO(1, "1", 1); //$NON-NLS-1$
        final DoctorDTO b = new DoctorDTO(2, "2", 2); //$NON-NLS-1$
        final DoctorDTO c = new DoctorDTO(3, "3", 3); //$NON-NLS-1$
        DoctorServiceImpl.arr.add(a);
        DoctorServiceImpl.arr.add(b);
        DoctorServiceImpl.arr.add(c);

    }

    private static List<DoctorDTO> arr;

    @Override
    public List<DoctorDTO> getAllDoctors() {
        return arr;
    }

    @Override
    public List<DoctorDTO> deleteDoctor(final int id) {
        arr.removeIf(dc -> dc.getId() == id);
        return arr;
    }

}
