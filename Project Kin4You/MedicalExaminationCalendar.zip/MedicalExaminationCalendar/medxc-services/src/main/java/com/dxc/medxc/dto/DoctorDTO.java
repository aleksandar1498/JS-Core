package com.dxc.medxc.dto;

/**
 * DTO class
 *
 * @author atsekov
 */
public final class DoctorDTO {

    private final int id;
    private final String name;
    private final int rating;
    private final boolean active;

    /**
     * @param id
     *            The id of the doctor
     * @param name
     *            The name of the doctor
     * @param rating
     *            The rating of the doctor
     */
    public DoctorDTO(final int id, final String name, final int rating) {
        this.id = id;
        this.name = name;
        this.rating = rating;
        this.active = true;
    }

    /**
     * @return int parameter id
     */
    public int getId() {
        return id;
    }

    /**
     * @return String parameter name
     */
    public String getName() {
        return name;
    }

    /**
     * @return int parameter rating
     */
    public int getRating() {
        return rating;
    }

    /**
     * @return boolean parameter active
     */
    public boolean isActive() {
        return active;
    }
}
