package com.dxc.medxc.services;

import java.util.List;

import com.dxc.medxc.dto.DoctorDTO;

/**
 * Interface for the doctor services
 *
 * @author atsekov
 */
public interface DoctorService {

    /**
     * Method to get all the doctors
     *
     * @return A list of all doctors
     */
    List<DoctorDTO> getAllDoctors();

    /**
     * Method to delete a doctor by id
     * 
     * @param id
     *            The id of the doctor to delete
     * @return A list of all remaining doctors
     */
    List<DoctorDTO> deleteDoctor(final int id);

}
